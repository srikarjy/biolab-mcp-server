# Biolab MCP Server

> *"AI agents querying biological databases leave no audit trail. Six months later, nobody can answer: what exact query returned this result, when, and was that paper peer-reviewed at the time? Biolab solves that."*

A Python MCP server that sits between AI agents and biological/scientific databases. Every query is intercepted, logged with full retrieval context, and returns a `retrieval_id` that calling systems can store alongside their own reasoning traces — creating an end-to-end auditable chain from conclusion back to raw source.

---

## The Problem

A drug discovery team uses an AI agent to research gene targets. The agent queries PubMed 200 times over three days and surfaces a paper claiming gene X is upregulated in pancreatic cancer. A scientist makes a decision based on that. Six months later, during FDA submission:

- What exact query returned that paper?
- What date was it retrieved?
- Was it peer-reviewed at retrieval time, or a preprint that was published later?
- Did the agent summarize it accurately, or did it hallucinate details?

Without Biolab, nobody can answer any of those questions. The retrieval is invisible.

---

## What Biolab Does

Biolab is an **interception and logging layer**, not a retrieval layer. It doesn't interpret evidence, rank it, or summarize it — it records what happened, verbatim, so an agent's claim can always be traced back to an unforgeable original.

When an agent calls a source tool:

```
Aletheia Advocate Agent
    ↓  MCP tool call (e.g. search_pubmed)
Biolab MCP Server
    ↓  HTTP
Source API (PubMed today; Europe PMC, ClinicalTrials.gov, bioRxiv in v2)
    ↓  paper
Biolab writes retrieval record to database
    ↓  paper + retrieval_id
Back to Advocate Agent
```

The agent gets the paper it asked for. Biolab gets a permanent, queryable record of exactly what happened.

---

## How It Fits Into Aletheia

Biolab is a dependency of Aletheia, a multi-agent scientific reasoning system. Aletheia's advocate agent retrieves evidence through Biolab. Aletheia stores `retrieval_id` alongside `source_paper_id` in its own provenance table.

```
Aletheia provenance table
    claim | agent | source_paper_id | retrieval_id | action | timestamp
                                          ↓
                              Biolab retrieval record
                              (full query context, snapshot at retrieval time, source metadata)
```

Without `retrieval_id`, you know which paper was used but not what it said when it was retrieved. With it, the chain is complete.

**Status:** proven end-to-end for a single call (Aletheia's Phase 1 retrieval script → `search_pubmed` → stored `retrieval_id`). Aletheia's advocate agent — a reasoning agent, not a script — driving this call is still ahead; that's the piece that closes the loop on the pitch above.

---

## Current State: v1 (shipped)

One MCP tool, one source, proven wiring.

| File | Responsibility |
|---|---|
| `biolab/pubmed_client.py` | esearch → PMIDs → efetch → parsed `PubMedPaper` |
| `biolab/retrieval_log.py` | The only module that writes to `retrievals` |
| `biolab/db.py` | SQLite connection + schema |
| `biolab/models.py` | `RetrievalRecord` dataclass, shared by storage and tool output |
| `biolab/server.py` | FastMCP entrypoint, input validation, orchestration |

**Tool:** `search_pubmed(query, agent_id, max_results=5)` — searches PubMed, writes one retrieval record per paper (not per query), returns each paper with its `retrieval_id`.

**Security:** untrusted network XML parsed with `defusedxml` (entity-expansion defense). `max_results` capped at 50.

**Tests:** 11 tests, no mocks — the suite hits live PubMed on every run, by deliberate choice (see Commandments and AD-13 below).

**Known gap:** there is currently no way to query the log back out (`get_retrieval` doesn't exist yet). `sqlite3` on the CLI is not a deliverable — this is the top item in v2.

---

## v2: In Progress

v2 is scoped narrowly on purpose — it closes real gaps in v1, it does not chase every idea that's been floated for this project. See "What v2 Explicitly Does Not Include" below for the guardrail.

### 1. Schema generalization
The v1 schema hardcodes PubMed's shape (`medline_status`, `pub_status` as required columns). v2 replaces this with a source-agnostic table:

```sql
retrieval_id     TEXT PRIMARY KEY
source           TEXT NOT NULL        -- "pubmed", "europepmc", "clinicaltrials", "biorxiv"
external_id      TEXT NOT NULL        -- replaces "pmid"
query_text       TEXT NOT NULL
retrieved_at     TEXT NOT NULL
agent_id         TEXT NOT NULL
source_metadata  TEXT NOT NULL        -- JSON: source-specific fields (e.g. medline_status, pub_status)
raw_response     TEXT NOT NULL
snapshot         TEXT NOT NULL        -- JSON: structured fields (title, abstract, authors, journal, pub types, MeSH terms, DOI)
response_hash    TEXT NOT NULL        -- hash of raw_response, for integrity checks
```

This is a migration on the existing 35 rows (backfilled as `source='pubmed'`), not a rewrite. `medline_status`/`pub_status` move into `source_metadata`.

### 2. `get_retrieval(retrieval_id)` MCP tool
Makes the audit trail actually queryable — the thinnest thing that makes "database, not log files" true in practice rather than in principle.

### 3. A shared source adapter interface
```python
class SourceClient(Protocol):
    source_name: str
    async def search(self, query: str, max_results: int) -> list[RawPaper]
```
`pubmed_client.py` is refactored to implement this (same parsing logic, same bug fixes, same security guard — just conforming to a shared shape). This refactor is itself a test: if PubMed doesn't fit its own interface cleanly, the interface is wrong before anything new gets built against it.

### 4. Three new source adapters
- **Europe PMC** — free, supports real keyword search, also indexes bioRxiv/medRxiv preprints
- **ClinicalTrials.gov** — free, structurally different from literature APIs (deliberate stress test of the schema)
- **bioRxiv** — free; its public API has no free-text search endpoint (date/category listing only), so this adapter is built around that shape rather than forced into the `search(query, ...)` contract — see Open Issues

### 5. Evidence Snapshot + hash
Structured fields (title, abstract, authors, journal, publication types, MeSH terms, DOI) pulled out at write time, alongside a hash of the raw response. This is the prerequisite for any future drift/retraction detection — you can't detect a paper's status changed without something to compare against.

---

## What v2 Explicitly Does Not Include

Named here on purpose, so it isn't quietly reintroduced mid-build:

- **Evidence Drift Detection** (retraction/correction monitoring) — real value, but depends on Evidence Snapshot existing first. Next version, not this one.
- **Retrieval Explorer UI / Replay CLI** — good for demos, not a prerequisite for anything else. Deferred.
- **Policy Engine (caching, retry, rate-limit routing)** — no evidence yet that current volume needs it. Commandment 1.
- **Provenance Graph** — a relational schema likely answers most real questions first. Build the graph when a real query fails without one, not before.
- **Nextflow / workflow integration** — out of scope for this project's current stage.
- **Evidence Quality Engine (scored ranking)** — rejected. Inventing weights (`+30` for a clinical trial, `-20` for a preprint) with no grounding is worse than not scoring at all. If this ever gets built, it gets built against a real framework (e.g. GRADE), not made-up numbers.
- **Compliance/ALCOA+ certification claims** — the design aligns with these principles (immutability, attribution, timestamping) but Biolab does not claim regulatory compliance.

---

## Why Every Decision Exists

### Python, not Go
The official MCP SDK is Python. Aletheia is Python. The biotech ecosystem is Python. A Go service introduces a language boundary at the most critical integration point with no performance justification — Aletheia makes sequential agent calls, not 10,000 concurrent ones.

### MCP tool, not REST API
Aletheia's agents call tools, not endpoints. Wrapping Biolab as an MCP tool means zero integration overhead on the Aletheia side.

### Database, not log files
"Show me everything retrieved for BRCA1 between June and August" is a SQL query, not a grep.

### SQLite, not Postgres (yet)
One writer, sequential calls, ~35 rows today. **Reversal trigger:** concurrent writers — with multiple source adapters potentially fetching in parallel in v2, `retrieval_log.py` needs an internal write-queue/lock before this trigger is hit by accident.

### No LangChain, no LangGraph
Provenance tracing is the core product. Every step must produce an inspectable record. That requires code you own, not a framework's internal routing.

### Hard-fail, never degrade
A paper returned without a `retrieval_id` is worse than an error — the agent will use it silently, and the audit chain has a hole nobody discovers until it matters. **v2 nuance:** with multiple sources queried together, a failure in one source should fail *that source* loudly, not silently drop it or take down the others.

### Store raw responses verbatim
Any parsing bug shipped today is recoverable tomorrow, because the ground truth is still on disk.

### Live-API tests, no mocks
The suite hits real APIs because that's what actually breaks — PubMed's real XML shape caught a genuine truncation bug (`m<sup>5</sup>C` silently cut short by naive `.text` parsing) that a mock would never have surfaced. **Reversal trigger for v2:** across 4 sources, test-suite flakiness from any one API having a bad day rises. If this starts eroding trust in the suite, add a recorded-cassette layer *alongside* live tests for the less-critical sources — not replacing them.

---

## Open Issues

1. **bioRxiv has no free-text search endpoint.** Its adapter is built around date/category listing rather than the `search(query, max_results)` contract the other adapters use. Europe PMC already indexes bioRxiv/medRxiv content with real keyword search, so there's real overlap to be aware of — the two are not fully redundant, but neither is bioRxiv's adapter a drop-in fit for the shared interface.
2. **Concurrency across adapters.** Fetching from multiple sources at once means multiple near-simultaneous writes to one SQLite file. Needs a write-queue in `retrieval_log.py` before it's a real bug instead of a theoretical one.
3. **`biolab.db` is gitignored.** Local evidence of the Aletheia integration (35 records as of v1) has no backup. Worth deciding: export step, or reverse the gitignore policy deliberately.

---

## Commandments

1. Don't add infrastructure until a real query fails without it.
2. Every retrieval produces a permanent, queryable record.
3. The `retrieval_id` is not optional — it is the link that makes Aletheia's traces auditable.
4. Never log the agent's summary instead of the raw source. One is interpretation. One is ground truth.
5. Biolab records what happened. It does not interpret, rank, or score it — that is Aletheia's job.
